/**
 * @file
 * Global utilities.
 *
 */
(function($, Drupal) {

  'use strict';

  Drupal.behaviors.YC_theme = {
    attach: function(context, settings) {

      // Custom code here

    }
  };

})(jQuery, Drupal);